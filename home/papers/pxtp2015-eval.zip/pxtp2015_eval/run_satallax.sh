#!/bin/bash

#/Users/nik/satallax2.7-isar/bin/satallax -t 60 -p isar $1
/Users/nik/satallax2.7-isar/bin/satallax -t 300 $1

