#!/bin/bash

/Users/nik/leo2_1.6.0/leo2/bin/leo -t 300 -nuc -nux --expand_extuni -po 1 --atp e=/Users/nik/E/PROVER/eprover $1

