Overview of Isabelle/HOL files.

It should be noted that these files were used to create the document BachelorThesisTiemens.PDF which is also incuded in this folder.

FreeLogic.thy
This file contains the shallow embedding of free logic by Benzmüller and Scott.


InverseCategories.thy
This file contains the definition of a category and the two formulations of an inverse category. It also contains the proof of the equivalence between the two formulations as far as automation worked.


InverseSemigroupTheory.thy
This file contains the definition of an inverse semigroup as well as the proof of the equivalence of the different characterizations of an inverse semigroup. Furthermore, it includes the automated lemma's and proposition's needed to prove the Wagner-Preston representation theorem. Small parts of the Wagner-Preston representation theorem are also automated.


