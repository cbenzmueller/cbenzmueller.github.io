/Applications/Isabelle2016.app/Isabelle/bin/isabelle build -D .
